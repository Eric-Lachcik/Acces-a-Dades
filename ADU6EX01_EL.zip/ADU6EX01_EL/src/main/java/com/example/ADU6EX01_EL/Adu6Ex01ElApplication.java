package com.example.ADU6EX01_EL;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Adu6Ex01ElApplication {

	public static void main(String[] args) {
		SpringApplication.run(Adu6Ex01ElApplication.class, args);
	}

}
