package com.example.ADU6EX01_EL;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Adu6Ex01ElApplicationTests {

	@Test
	void contextLoads() {
	}

}
