package com.example.ADU7EX01_EL_Franky.Repositorys;

import com.example.ADU7EX01_EL_Franky.Clases.Cadena;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CadenaRepository extends JpaRepository<Cadena, Integer> {
  }