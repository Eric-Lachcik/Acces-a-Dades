package com.example.ADU7EX01_EL_Franky;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Adu7Ex01ElFrankyApplicationTests {

	@Test
	void contextLoads() {
	}

}
